package com.example.fragmentexample;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState == null) {
            Fragment myFragment = new MyFragment();
            Fragment2 fragment2 = new Fragment2();
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

            // Add both fragments to the layout
            transaction.replace(R.id.fragment_container, myFragment);
            transaction.replace(R.id.fragment2_container, fragment2, "Fragment2");

            transaction.commit();
        }
    }


        public void sendDataToFragment_2(String data){
            Fragment2 fragment2 = (Fragment2) getSupportFragmentManager().findFragmentById(R.id.fragment2_container);
            if (fragment2 != null){
                fragment2.updateData(data);
            }
        }

    }

