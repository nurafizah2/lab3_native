package com.example.sharedpreferencesdemo

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
private lateinit var greetingTextView: TextView
private lateinit var nameEditText: EditText
private lateinit var saveButton: Button
private lateinit var loadButton: Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        greetingTextView = findViewById(R.id.tv_greeting)
        nameEditText = findViewById(R.id.et_name)
        saveButton = findViewById(R.id.btn_save)
        loadButton = findViewById(R.id.btn_load)

        saveButton.setOnClickListener{
            saveName()
        }

        loadButton.setOnClickListener{
            loadName()
        }

    }

    private fun saveName(){
        val sharedPreferences = getSharedPreferences("User Preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        val name = nameEditText.text.toString()
        editor.putString("userName",name)
        editor.apply()
        greetingTextView.text = "Name saved!"
    }

    private fun loadName(){
        val sharedPreferences = getSharedPreferences("User Preferences", Context.MODE_PRIVATE)
        val savedName = sharedPreferences.getString("UserName", "No name saved")
        greetingTextView.text = "Welcome, $savedName!"
    }
}